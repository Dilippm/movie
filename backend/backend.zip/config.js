module.exports = {
    JWT_SECRET: "MY SECRET",
    // MongoDB_URL:"mongodb://127.0.0.1:27017/movietimes",
    MongoDB_URL:"mongodb+srv://dilippm:06111992@cluster0.j7fdhcd.mongodb.net/movietimes",

    BASE_URL:"http://localhost:5000/public/images",
    CLIENT_URL:'http://localhost:3000',
    
  };